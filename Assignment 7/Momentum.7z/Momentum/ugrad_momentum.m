% Tom Makkink
% Exercise 5.5.1 (2)
% Ugrad problem with momentum 
%---------------------------------------------------------------------------

clc 
clear all
close all 

%% 
%----------------------------------------------------------------------
% Arrange the data 
%----------------------------------------------------------------------
Data = importdata('ugraddata5.txt');
P = Data(:, [1 2 3]);
T = Data(:, [4 5]);

% Arrange as rows 
p = P';
t = T';

% Check 
[r,q] = size(p);
[s,qt] = size(t);

if q~=qt 
    error ('different batch sizes');
end 

%%
%----------------------------------------------------------------------
% Scale down 
%----------------------------------------------------------------------
% Scale down the inputs by row 
pMax = max(p,[],2);
pMin = min(p,[],2);
pf = 2./(pMax - pMin);            % Factors to scale down rows 
pc = -(pMax+pMin)./(pMax-pMin);   % Additive terms 
Dp = diag(pf);                    % pf down the diagonal of Dp 
pn = Dp*p+repmat(pc,1,size(p,2)); % Scale down 

% Scale down the targets 
tMax = max(t,[],2);
tMin = min(t,[],2);
tf = 2./(tMax-tMin);
tc = -(tMax + tMin)./(tMax-tMin);
Dt = diag(tf);
tn = Dt*t + repmat(tc,1,size(t,2));

%%
%----------------------------------------------------------------------
% Divide training and test sets by index 
%----------------------------------------------------------------------

% Train Index 
I1 = randperm(floor(2*q/3));      % Train 2/3rds of the data  
q1 = length(I1);

% Test index 
I2 = setdiff([1:q],I1);
q2 = length(I2);

% Training set:
p1 = p(:, I1);
t1 = t(:,I1);

p1n = pn(:, I1);                  % Scaled versions 
t1n = tn(:,I1);

% Test set 
p2 = p(:,I2);
t2 = t(:,I2);

p2n = pn(:, I2);                  % Scaled versions 
t2n = tn(:, I2);

%%
%----------------------------------------------------------------------
% Network architecture 
%----------------------------------------------------------------------
%
%         W1(s1Xr)       W2(s2Xs1)       W3(s3Xs2)
% p(2Xq) ----------> a1 ----------> a2  ----------> a3 (s3Xq)
%         b1(s1X1)       b2(s2Xs1)       b3(s3Xs2)
%
%                 tansig          logsig          purelin
%----------------------------------------------------------------------

% Layer sizes 
s1 = 9;
s2 = 9;
s3 = s;

% Transfer Functions 
f1 = @tansig;
f2 = @logsig;
f3 = @purelin;

% Epoch counter
k = 1;

% Initialise Books 
W1(:,:,k)=randu(-1,1,s1,r);
b1(:,:,k)=randu(-1,1,s1,1);
W2(:,:,k)=randu(-1,1,s2,s1);
b2(:,:,k)=randu(-1,1,s2,1);
W3(:,:,k)=randu(-1,1,s3,s2);
b3(:,:,k)=randu(-1,1,s3,1);

%%
%----------------------------------------------------------------------
% Training Parameters 
%----------------------------------------------------------------------
% Learning rate 
h1 = .005;

% Momentum 
h2 = 0.6;
 
%% 
%----------------------------------------------------------------------
% Propogate once through the network and get first error
%----------------------------------------------------------------------
j = 1;

% Propagate input patterns through the network 
n1 = W1(:,:,k)*p1n(:,j) + b1(:,:,k);
a1 = f1(n1);
n2 = W2(:,:,k)*a1 + b2(:,:,k);
a2 = f2(n2);
n3 = W3(:,:,k)*a2 + b3(:,:,k);
a3 = f3(n3);
an(:,j) = a3;

% jth error vector 
e(:,j) = t1n(:,j) - an(:,j);

% Derivative matrices 
D3 = eye(s3);
D2 = diag((1-a2).*a2);
D1 = diag(1 -a1.^2);

% Sensitivities 
S3 = -2*D3*e(:,j);
S2 = D2*W3(:,:,k)'*S3;
S1 = D1*W2(:,:,k)'*S2;

% Update the weights and the biases 
W3(:,:,k+1)=W3(:,:,k)-h1*S3*a2';
b3(:,:,k+1)=b3(:,:,k)-h1*S3;
W2(:,:,k+1)=W2(:,:,k)-h1*S2*a1';
b2(:,:,k+1)=b2(:,:,k)-h1*S2;
W1(:,:,k+1)=W1(:,:,k)-h1*S1*p1n(:,j)';
b1(:,:,k+1)=b1(:,:,k)-h1*S1;

% Error for epoch 
mse = sum(sum(e).^2)/q1;

% accumulate MSE into vector: EE
E(k) = mse; 

% Set tolerance 
tol=1e-6;

% Max iterations 
maxit = 100;

%%
%----------------------------------------------------------------------
% Train on normalised data 
%----------------------------------------------------------------------
while mse > tol & k < maxit 
    k = k+1;
    for j = 1:q1
        % Propagate input patterns through the network 
        n1 = W1(:,:,k)*p1n(:,j) + b1(:,:,k);
        a1 = f1(n1);
        n2 = W2(:,:,k)*a1 + b2(:,:,k);
        a2 = f2(n2);
        n3 = W3(:,:,k)*a2 + b3(:,:,k);
        a3 = f3(n3);
        an(:,j) = a3;

        % jth error vector 
        e(:,j) = t1n(:,j) - an(:,j);

        % Derivative matrices 
        D3 = eye(s3);
        D2 = diag((1-a2).*a2);
        D1 = diag(1 -a1.^2);

        % Sensitivities 
        S3 = -2*D3*e(:,j);
        S2 = D2*W3(:,:,k)'*S3;
        S1 = D1*W2(:,:,k)'*S2;

        % Update the weights and the biases 
        W3(:,:,k+1)=W3(:,:,k)-h1*S3*a2'+h2*(W3(:,:,k)-W3(:,:,k-1));
        b3(:,:,k+1)=b3(:,:,k)-h1*S3+h2*(b3(:,:,k)-b3(:,:,k-1));
        W2(:,:,k+1)=W2(:,:,k)-h1*S2*a1'+h2*(W2(:,:,k)-W2(:,:,k-1));
        b2(:,:,k+1)=b2(:,:,k)-h1*S2+h2*(b2(:,:,k)-b2(:,:,k-1));
        W1(:,:,k+1)=W1(:,:,k)-h1*S1*p1n(:,j)'+h2*(W1(:,:,k)-W1(:,:,k-1));
        b1(:,:,k+1)=b1(:,:,k)-h1*S1+h2*(b1(:,:,k)-b1(:,:,k-1));
    end 
    
    % Error for epoch 
    mse = sum(sum(e).^2)/q1;

    % accumulate MSE into vector: EE
    E(k) = mse; 
end

% scale up 
a = diag(1./tf)*(an-repmat(tc,1,size(t1,2)));

%% 
%----------------------------------------------------------------------
% Assessing the degree of fit
%----------------------------------------------------------------------

%R^2 statistic
r2=rsq(t1,a);

%corrcoeff
[R1,PV1]=corrcoef(a(1,:),t1(1,:));
fprintf('Traingin: Semester 1:\n\n')
fprintf('Correlation Coefficient: %g\n p value: %g\n r2: %g\n',R1(1,2),PV1(1,2),r2(1))
disp('------------------------------------------------------------------------')

[R2,PV2]=corrcoef(a(2,:),t1(2,:));
fprintf('Training: Semester 2\n\n')
fprintf('Correlation Coefficient: %g\n p value: %g\n r2: %g\n',R2(1,2),PV2(1,2),r2(2))
disp('------------------------------------------------------------------------')

%% 
%----------------------------------------------------------------------
% Plot
%----------------------------------------------------------------------
close all
E=E(2:end);
plot(E)
title('MSE')
xlabel('Iterations')
ylabel('Error')

% Save the variables from training 
save ugrad_mom.mat

disp('Training complete.');









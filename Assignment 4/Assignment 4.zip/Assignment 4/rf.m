% Regression function 
function y = rf(t,M,k)
y = M.*sin(k.*t);
return 
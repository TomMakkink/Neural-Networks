
cancer.txt has 9 attributes and two outputs:

2=benign
4=malignant


Cancer2 has ? replaced by the value 4



cancer3 has ? replaced by NaN

